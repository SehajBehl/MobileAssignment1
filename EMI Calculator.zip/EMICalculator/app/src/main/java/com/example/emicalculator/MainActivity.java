package com.example.emicalculator;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @SuppressLint("DefaultLocale")
    public void EMI(View view) {
        try {
            // First, calculate and display the EMI before starting a new activity.
            EditText mortgageInput = findViewById(R.id.mortgageInput);
            String inputText = mortgageInput.getText().toString();
            // Principal amount calculation
            double mortgageAmount = Double.parseDouble(inputText);

            EditText interestRateInput = findViewById(R.id.InterestRateInput);
            String interestRateText = interestRateInput.getText().toString();
            // Interest rate calculation (dividing by 100 to convert percentage to decimal)
            double interestRate = Double.parseDouble(interestRateText) / 100;

            EditText amorPeriodInput = findViewById(R.id.Amor_period);
            String amorPeriodText = amorPeriodInput.getText().toString();
            // Amortization period calculation
            double amorYears = Double.parseDouble(amorPeriodText);

            // EMI Calculation
            double emiResult = Calculation(mortgageAmount, interestRate, amorYears);






            Intent intent = new Intent(this, EMI.class);
            intent.putExtra("emiResult", String.valueOf(emiResult));
            startActivity(intent);

//            startActivity(new Intent(this,EMI.class));
        } catch(NumberFormatException e) {
            Toast.makeText(this,"Please enter valid numbers",Toast.LENGTH_SHORT).show();
        }
    }

    public double Calculation(double P, double r, double n) {
        double monthlyRate = r / 12;
        int months = (int)(n * 12);
        double EMI = (P * monthlyRate * Math.pow(1 + monthlyRate, months)) /
                (Math.pow(1 + monthlyRate, months) - 1);

        double scale = Math.pow(10, 2);

        return Math.ceil(EMI * scale) / scale;
    }

}